import StrategyCompiler
import ResolutionBridge
import FallbackRawResolution

namespace WTCF21
open WTC

set_option maxRecDepth 100000
set_option maxHeartbeats 5000000

def fallbackRawCompiled : ClosedSubsetCompiled := compileClosedSubset fallbackDemo
def fallbackRawTarget : CNF := compileProgram fallbackRawCompiled.insts fallbackRawCompiled.output

/-- The standard LRAT proof was generated from the raw WTC DIMACS target, so no
    normalization bridge is required. -/
theorem fallback_raw_context_exact :
    toRCNF fallbackRawTarget = WTCFrontier13.lightCoreStatic := by
  rfl

theorem fallback_raw_target_unsat : ¬ ∃ a, SatCNF a fallbackRawTarget := by
  rintro ⟨a, hsat⟩
  have hr : SatRCNF a (toRCNF fallbackRawTarget) :=
    (satCNF_toRCNF_iff a fallbackRawTarget).mpr hsat
  rw [fallback_raw_context_exact] at hr
  exact WTCFrontier13.lightCore_unsat a hr

theorem fallback_no_source_witness :
    ¬ ∃ base : Assignment, naturalSubsetAccepts fallbackDemo base := by
  intro hsrc
  have hsat := (naturalSubsetSum_exists_iff_target_sat fallbackDemo_wf).mp hsrc
  exact fallback_raw_target_unsat hsat

theorem strategy_fallback_closed :
    (chooseStrategy fallbackDemo).tag = .lrat ∧
    ¬ ∃ base : Assignment, naturalSubsetAccepts fallbackDemo base := by
  exact ⟨fallbackDemo_selects_lrat, fallback_no_source_witness⟩

#print axioms fallback_raw_context_exact
#print axioms fallback_raw_target_unsat
#print axioms fallback_no_source_witness
#print axioms strategy_fallback_closed

end WTCF21
