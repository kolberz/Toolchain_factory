import SSATseitin

namespace WTC

inductive BExpr where
  | var (w : Nat)
  | const (v : Bool)
  | not (e : BExpr)
  | and (l r : BExpr)
  | or (l r : BExpr)
  deriving DecidableEq, Repr

def BExpr.eval (a : Assignment) : BExpr → Bool
  | .var w => a w
  | .const v => v
  | .not e => !(e.eval a)
  | .and l r => l.eval a && r.eval a
  | .or l r => l.eval a || r.eval a

def BExpr.VarsBelow (bound : Nat) : BExpr → Prop
  | .var w => w < bound
  | .const _ => True
  | .not e => e.VarsBelow bound
  | .and l r => l.VarsBelow bound ∧ r.VarsBelow bound
  | .or l r => l.VarsBelow bound ∧ r.VarsBelow bound

structure CompiledExpr where
  insts : List TInstr
  output : Nat
  deriving Repr

def compileExpr : Nat → BExpr → CompiledExpr
  | _, .var w => ⟨[], w⟩
  | next, .const v => ⟨[.const next v], next⟩
  | next, .not e =>
      let c := compileExpr next e
      let d := next + c.insts.length
      ⟨c.insts ++ [.not d c.output], d⟩
  | next, .and l r =>
      let cl := compileExpr next l
      let cr := compileExpr (next + cl.insts.length) r
      let d := next + cl.insts.length + cr.insts.length
      ⟨cl.insts ++ cr.insts ++ [.and d cl.output cr.output], d⟩
  | next, .or l r =>
      let cl := compileExpr next l
      let cr := compileExpr (next + cl.insts.length) r
      let d := next + cl.insts.length + cr.insts.length
      ⟨cl.insts ++ cr.insts ++ [.or d cl.output cr.output], d⟩

theorem varsBelow_mono {e : BExpr} {m n : Nat}
    (h : e.VarsBelow m) (hmn : m ≤ n) : e.VarsBelow n := by
  induction e with
  | var w => exact Nat.lt_of_lt_of_le h hmn
  | const v => trivial
  | not e ih => exact ih h
  | and l r ihl ihr => exact ⟨ihl h.1, ihr h.2⟩
  | or l r ihl ihr => exact ⟨ihl h.1, ihr h.2⟩

theorem eval_congr_below {e : BExpr} {a b : Assignment} {bound : Nat}
    (hv : e.VarsBelow bound) (hab : AgreesBelow a b bound) :
    e.eval a = e.eval b := by
  induction e with
  | var w => exact hab w hv
  | const v => rfl
  | not e ih => simp [BExpr.eval, ih hv]
  | and l r ihl ihr => simp [BExpr.eval, ihl hv.1, ihr hv.2]
  | or l r ihl ihr => simp [BExpr.eval, ihl hv.1, ihr hv.2]

theorem programWF_append {next : Nat} {xs ys : List TInstr}
    (hx : programWF next xs)
    (hy : programWF (next + xs.length) ys) :
    programWF next (xs ++ ys) := by
  induction xs generalizing next with
  | nil => simpa using hy
  | cons i rest ih =>
      rcases hx with ⟨hi, hrest⟩
      constructor
      · exact hi
      · apply ih hrest
        simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hy

theorem exec_append (a : Assignment) (xs ys : List TInstr) :
    exec a (xs ++ ys) = exec (exec a xs) ys := by
  induction xs generalizing a with
  | nil => rfl
  | cons i rest ih =>
      simp [exec, ih]

theorem compileExpr_shape {e : BExpr} {next : Nat}
    (hv : e.VarsBelow next) :
    let c := compileExpr next e
    programWF next c.insts ∧ c.output < next + c.insts.length := by
  induction e generalizing next with
  | var w =>
      constructor
      · trivial
      · exact hv
  | const v =>
      constructor
      · simp [compileExpr, programWF, TInstr.WellFormedAt, TInstr.dst, TInstr.args]
      · simp [compileExpr]
  | not e ih =>
      have hc := ih (next := next) hv
      let c := compileExpr next e
      have hwf : programWF next c.insts := by simpa [c] using hc.1
      have hout : c.output < next + c.insts.length := by simpa [c] using hc.2
      let d := next + c.insts.length
      have hlast : programWF d [TInstr.not d c.output] := by
        simp [programWF, TInstr.WellFormedAt, TInstr.dst, TInstr.args, d, hout]
      have hall := programWF_append hwf hlast
      constructor
      · simpa [compileExpr, c, d] using hall
      · simp [compileExpr, c, d]
  | and l r ihl ihr =>
      rcases hv with ⟨hlv, hrv⟩
      let cl := compileExpr next l
      have hlshape := ihl (next := next) hlv
      have hlwf : programWF next cl.insts := by simpa [cl] using hlshape.1
      have hlout : cl.output < next + cl.insts.length := by simpa [cl] using hlshape.2
      let mid := next + cl.insts.length
      have hrv' : r.VarsBelow mid := varsBelow_mono hrv (by omega)
      let cr := compileExpr mid r
      have hrshape := ihr (next := mid) hrv'
      have hrwf : programWF mid cr.insts := by simpa [cr] using hrshape.1
      have hrout : cr.output < mid + cr.insts.length := by simpa [cr] using hrshape.2
      let d := mid + cr.insts.length
      have hpref : programWF next (cl.insts ++ cr.insts) := programWF_append hlwf hrwf
      have hleft : cl.output < d := by omega
      have hlast : programWF d [TInstr.and d cl.output cr.output] := by
        simp [programWF, TInstr.WellFormedAt, TInstr.dst, TInstr.args, hleft, d, hrout, mid]
      have hlast' : programWF (next + (cl.insts ++ cr.insts).length)
          [TInstr.and d cl.output cr.output] := by
        simpa [d, mid, Nat.add_assoc] using hlast
      have hall := programWF_append hpref hlast'
      constructor
      · simpa [compileExpr, cl, cr, mid, d, List.append_assoc, Nat.add_assoc] using hall
      · simp [compileExpr, cl, cr, mid, d, Nat.add_assoc]
  | or l r ihl ihr =>
      rcases hv with ⟨hlv, hrv⟩
      let cl := compileExpr next l
      have hlshape := ihl (next := next) hlv
      have hlwf : programWF next cl.insts := by simpa [cl] using hlshape.1
      have hlout : cl.output < next + cl.insts.length := by simpa [cl] using hlshape.2
      let mid := next + cl.insts.length
      have hrv' : r.VarsBelow mid := varsBelow_mono hrv (by omega)
      let cr := compileExpr mid r
      have hrshape := ihr (next := mid) hrv'
      have hrwf : programWF mid cr.insts := by simpa [cr] using hrshape.1
      have hrout : cr.output < mid + cr.insts.length := by simpa [cr] using hrshape.2
      let d := mid + cr.insts.length
      have hpref : programWF next (cl.insts ++ cr.insts) := programWF_append hlwf hrwf
      have hleft : cl.output < d := by omega
      have hlast : programWF d [TInstr.or d cl.output cr.output] := by
        simp [programWF, TInstr.WellFormedAt, TInstr.dst, TInstr.args, hleft, d, hrout, mid]
      have hlast' : programWF (next + (cl.insts ++ cr.insts).length)
          [TInstr.or d cl.output cr.output] := by
        simpa [d, mid, Nat.add_assoc] using hlast
      have hall := programWF_append hpref hlast'
      constructor
      · simpa [compileExpr, cl, cr, mid, d, List.append_assoc, Nat.add_assoc] using hall
      · simp [compileExpr, cl, cr, mid, d, Nat.add_assoc]

theorem compileExpr_semantics {e : BExpr} {next : Nat} {a : Assignment}
    (hv : e.VarsBelow next) :
    let c := compileExpr next e
    exec a c.insts c.output = e.eval a := by
  induction e generalizing next a with
  | var w => rfl
  | const v => simp [compileExpr, exec, execOne, evalInstr, update, TInstr.dst, BExpr.eval]
  | not e ih =>
      let c := compileExpr next e
      have hcshape := compileExpr_shape (e := e) (next := next) hv
      have hcw : programWF next c.insts := by simpa [c] using hcshape.1
      have hsem := ih (next := next) (a := a) hv
      have hsem' : exec a c.insts c.output = e.eval a := by simpa [c] using hsem
      let d := next + c.insts.length
      have hout : c.output < d := by simpa [c, d] using hcshape.2
      change exec a (c.insts ++ [TInstr.not d c.output]) d = !(e.eval a)
      rw [exec_append]
      simp [exec, execOne, evalInstr, update, TInstr.dst, d, hsem', BExpr.eval]
  | and l r ihl ihr =>
      rcases hv with ⟨hlv, hrv⟩
      let cl := compileExpr next l
      have hlshape := compileExpr_shape (e := l) (next := next) hlv
      have hlwf : programWF next cl.insts := by simpa [cl] using hlshape.1
      have hlout : cl.output < next + cl.insts.length := by simpa [cl] using hlshape.2
      let mid := next + cl.insts.length
      have hrv' : r.VarsBelow mid := varsBelow_mono hrv (by omega)
      let cr := compileExpr mid r
      have hrshape := compileExpr_shape (e := r) (next := mid) hrv'
      have hrwf : programWF mid cr.insts := by simpa [cr] using hrshape.1
      have hrout : cr.output < mid + cr.insts.length := by simpa [cr] using hrshape.2
      let a1 := exec a cl.insts
      let a2 := exec a1 cr.insts
      have hlsem := ihl (next := next) (a := a) hlv
      have hlsem' : exec a cl.insts cl.output = l.eval a := by simpa [cl] using hlsem
      have hrsem1 := ihr (next := mid) (a := a1) hrv'
      have hrsem1' : exec a1 cr.insts cr.output = r.eval a1 := by simpa [cr] using hrsem1
      have hpres0 : AgreesBelow a1 a next := exec_preserves_below hlwf
      have hreval : r.eval a1 = r.eval a := eval_congr_below hrv hpres0
      have hleftPres : a2 cl.output = a1 cl.output := by
        exact exec_preserves_below hrwf cl.output hlout
      let d := mid + cr.insts.length
      change exec a (cl.insts ++ cr.insts ++ [TInstr.and d cl.output cr.output]) d =
        (l.eval a && r.eval a)
      rw [exec_append, exec_append]
      simp [exec, execOne, evalInstr, update, TInstr.dst, d, a1, a2, hleftPres, hlsem', hrsem1', hreval, BExpr.eval]
  | or l r ihl ihr =>
      rcases hv with ⟨hlv, hrv⟩
      let cl := compileExpr next l
      have hlshape := compileExpr_shape (e := l) (next := next) hlv
      have hlwf : programWF next cl.insts := by simpa [cl] using hlshape.1
      have hlout : cl.output < next + cl.insts.length := by simpa [cl] using hlshape.2
      let mid := next + cl.insts.length
      have hrv' : r.VarsBelow mid := varsBelow_mono hrv (by omega)
      let cr := compileExpr mid r
      have hrshape := compileExpr_shape (e := r) (next := mid) hrv'
      have hrwf : programWF mid cr.insts := by simpa [cr] using hrshape.1
      have hrout : cr.output < mid + cr.insts.length := by simpa [cr] using hrshape.2
      let a1 := exec a cl.insts
      let a2 := exec a1 cr.insts
      have hlsem := ihl (next := next) (a := a) hlv
      have hlsem' : exec a cl.insts cl.output = l.eval a := by simpa [cl] using hlsem
      have hrsem1 := ihr (next := mid) (a := a1) hrv'
      have hrsem1' : exec a1 cr.insts cr.output = r.eval a1 := by simpa [cr] using hrsem1
      have hpres0 : AgreesBelow a1 a next := exec_preserves_below hlwf
      have hreval : r.eval a1 = r.eval a := eval_congr_below hrv hpres0
      have hleftPres : a2 cl.output = a1 cl.output := by
        exact exec_preserves_below hrwf cl.output hlout
      let d := mid + cr.insts.length
      change exec a (cl.insts ++ cr.insts ++ [TInstr.or d cl.output cr.output]) d =
        (l.eval a || r.eval a)
      rw [exec_append, exec_append]
      simp [exec, execOne, evalInstr, update, TInstr.dst, d, a1, a2, hleftPres, hlsem', hrsem1', hreval, BExpr.eval]

theorem expr_acceptance_iff_exists_cnf_extension
    {e : BExpr} {next : Nat} {base : Assignment}
    (hv : e.VarsBelow next) :
    let c := compileExpr next e
    e.eval base = true ↔
      ∃ a, AgreesBelow a base next ∧ SatCNF a (compileProgram c.insts c.output) := by
  let c := compileExpr next e
  have hshape := compileExpr_shape (e := e) (next := next) hv
  have hsem := compileExpr_semantics (e := e) (next := next) (a := base) hv
  have hback := backend_acceptance_iff_exists_cnf_extension
    (base := base) hshape.1 hshape.2
  simpa [c, hsem] using hback

#print axioms WTC.compileExpr_shape
#print axioms WTC.compileExpr_semantics
#print axioms WTC.expr_acceptance_iff_exists_cnf_extension

end WTC
