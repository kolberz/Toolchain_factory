import NaturalSubsetFrontend

namespace WTC

def selectorWires (n : Nat) : List Nat := List.range n

@[simp] theorem selectorWires_length (n : Nat) : (selectorWires n).length = n := by
  simp [selectorWires]

theorem selectorWires_below (n : Nat) : WiresBelow (selectorWires n) n := by
  intro w hw
  simpa [selectorWires] using (List.mem_range.mp hw)

structure ClosedSubsetCompiled where
  insts : List TInstr
  output : Nat
  deriving Repr

/-- Closed reduction target: selector wires are free source-witness variables 0..n-1;
    wire n is generated as a certified false constant; all arithmetic and comparison
    wires are generated after it. -/
def compileClosedSubset (I : SubsetSumFW) : ClosedSubsetCompiled :=
  let n := I.values.length
  let falseWire := n
  let start := n + 1
  let sels := selectorWires n
  let acc := List.replicate I.width falseWire
  let core := compileSharedSubset start sels I.values acc falseWire falseWire I.target
  ⟨TInstr.const falseWire false :: core.insts, core.output⟩

/-- Ordinary natural-number source witness relation for the closed reduction. -/
def naturalSubsetAccepts (I : SubsetSumFW) (base : Assignment) : Prop :=
  selectedValue (readWires base (selectorWires I.values.length)) I.values = wordValue I.target

def naturalSubsetWitnessBits (I : SubsetSumFW) (base : Assignment) : List Bool :=
  readWires base (selectorWires I.values.length)

@[simp] theorem naturalSubsetWitnessBits_length (I : SubsetSumFW) (base : Assignment) :
    (naturalSubsetWitnessBits I base).length = I.values.length := by
  simp [naturalSubsetWitnessBits, readWires, selectorWires]

theorem naturalSubsetAccepts_congr {I : SubsetSumFW} {a b : Assignment}
    (hab : AgreesBelow a b I.values.length) :
    naturalSubsetAccepts I a ↔ naturalSubsetAccepts I b := by
  have hr := readWires_agree (selectorWires_below I.values.length) hab
  simp [naturalSubsetAccepts, hr]

theorem compileClosedSubset_shape {I : SubsetSumFW} (hI : I.WellFormed) :
    let n := I.values.length
    let c := compileClosedSubset I
    programWF n c.insts ∧ c.output < n + c.insts.length := by
  rcases hI with ⟨htarget, hvals⟩
  let n := I.values.length
  let fw := n
  let start := n + 1
  let sels := selectorWires n
  let acc := List.replicate I.width fw
  let core := compileSharedSubset start sels I.values acc fw fw I.target
  have hhead : programWF n [TInstr.const fw false] := by
    simp [programWF, TInstr.WellFormedAt, TInstr.dst, TInstr.args, fw]
  have hsv : sels.length = I.values.length := by simp [sels, n]
  have hacclen : acc.length = I.width := by simp [acc]
  have hvalsAcc : ∀ v ∈ I.values, v.length = acc.length := by
    intro v hv
    rw [hacclen]
    exact hvals v hv
  have hselsn : WiresBelow sels n := by simpa [sels] using selectorWires_below n
  have hsels : WiresBelow sels start := wiresBelow_mono hselsn (by simp [start])
  have hacc : WiresBelow acc start := by
    simpa [acc, fw, start] using replicate_falseWire_below (width := I.width) (by omega : n < n + 1)
  have hfw : fw < start := by simp [fw, start]
  have hcore := compileSharedSubset_shape (target := I.target)
    hsv hvalsAcc hsels hacc hfw hfw
  have hcorewf : programWF start core.insts := by simpa [core] using hcore.1
  have hcoreout : core.output < start + core.insts.length := by simpa [core] using hcore.2
  have hall := programWF_append hhead hcorewf
  constructor
  · simpa [compileClosedSubset, n, fw, start, sels, acc, core] using hall
  · have hout' : core.output < n + (core.insts.length + 1) := by omega
    simpa [compileClosedSubset, n, fw, start, sels, acc, core] using hout'

/-- The closed target executes exactly the independent natural-number source verifier. -/
theorem compileClosedSubset_semantics {I : SubsetSumFW} (hI : I.WellFormed) (base : Assignment) :
    let c := compileClosedSubset I
    exec base c.insts c.output = true ↔ naturalSubsetAccepts I base := by
  rcases hI with ⟨htarget, hvals⟩
  let n := I.values.length
  let fw := n
  let start := n + 1
  let sels := selectorWires n
  let acc := List.replicate I.width fw
  let head := TInstr.const fw false
  let base1 := execOne base head
  let core := compileSharedSubset start sels I.values acc fw fw I.target
  have hheadWF : head.WellFormedAt n := by
    simp [head, fw, TInstr.WellFormedAt, TInstr.dst, TInstr.args]
  have hpres : AgreesBelow base1 base n := by
    simpa [base1] using execOne_agrees_below hheadWF
  have hfwVal : base1 fw = false := by
    have hs := execOne_sets_dst (a := base) hheadWF
    simpa [base1, head, fw, evalInstr] using hs
  have hsv : sels.length = I.values.length := by simp [sels, n]
  have hacclen : acc.length = I.width := by simp [acc]
  have hvalsAcc : ∀ v ∈ I.values, v.length = acc.length := by
    intro v hv; rw [hacclen]; exact hvals v hv
  have hselsn : WiresBelow sels n := by simpa [sels] using selectorWires_below n
  have hsels : WiresBelow sels start := wiresBelow_mono hselsn (by simp [start])
  have hacc : WiresBelow acc start := by
    simpa [acc, fw, start] using replicate_falseWire_below (width := I.width) (by omega : n < n + 1)
  have hfw : fw < start := by simp [fw, start]
  have hcoreSem := compileSharedSubset_semantics (base := base1) (target := I.target)
    hsv hvalsAcc hsels hacc hfw hfw hfwVal
  have hsrcEq := sharedSubsetVerify_standard_eq base1 sels I.values I.width fw I.target hfwVal
  have hfixed := fixedSubsetVerify_iff_nat
    (sels := readWires base1 sels) (vals := I.values) (width := I.width) (target := I.target)
    (by simpa [readWires, sels, n] using hsv) hvals htarget
  have hselsRead : readWires base1 sels = readWires base sels := readWires_agree hselsn hpres
  change exec base (head :: core.insts) core.output = true ↔ _
  change exec base1 core.insts core.output = true ↔ _
  have hcoreEq : exec base1 core.insts core.output =
      sharedSubsetVerify base1 sels I.values acc fw I.target := by
    simpa [core] using hcoreSem
  rw [hcoreEq, hsrcEq]
  rw [hfixed]
  simp [naturalSubsetAccepts, sels, n, hselsRead]

/-- Global many-one reduction theorem: a natural subset-sum witness exists iff the
    single compiled Tseitin CNF is satisfiable.  No fixed source assignment is carried
    into the target; selector wires remain free and the false/zero wire is generated
    inside the target program. -/
theorem naturalSubsetSum_exists_iff_target_sat {I : SubsetSumFW} (hI : I.WellFormed) :
    (∃ base : Assignment, naturalSubsetAccepts I base) ↔
      ∃ a, SatCNF a (compileProgram (compileClosedSubset I).insts (compileClosedSubset I).output) := by
  let n := I.values.length
  let c := compileClosedSubset I
  have hshape := compileClosedSubset_shape hI
  have hback (base : Assignment) := backend_acceptance_iff_exists_cnf_extension
    (base := base) (insts := c.insts) (output := c.output)
    (by simpa [c, n] using hshape.1) (by simpa [c, n] using hshape.2)
  have hsem (base : Assignment) := compileClosedSubset_semantics hI base
  constructor
  · rintro ⟨base, hsrc⟩
    have hsem' : exec base c.insts c.output = true ↔ naturalSubsetAccepts I base := by
      simpa [c] using (hsem base)
    have hexec : exec base c.insts c.output = true := hsem'.2 hsrc
    rcases (hback base).1 hexec with ⟨a, _, ha⟩
    exact ⟨a, by simpa [c] using ha⟩
  · rintro ⟨a, ha⟩
    have haa : AgreesBelow a a n := by intro w hw; rfl
    have hexec : exec a c.insts c.output = true := by
      apply (hback a).2
      exact ⟨a, haa, by simpa [c] using ha⟩
    have hsem' : exec a c.insts c.output = true ↔ naturalSubsetAccepts I a := by
      simpa [c] using (hsem a)
    have hs := hsem'.1 hexec
    exact ⟨a, hs⟩

/-- Closed target size is linear in item-count times width. -/
theorem compileClosedSubset_cnf_clause_bound {I : SubsetSumFW} (hI : I.WellFormed) :
    (compileProgram (compileClosedSubset I).insts (compileClosedSubset I).output).length ≤
      3 * (1 + I.values.length * (20 * I.width + 1) + (2 * I.width + 3)) + 1 := by
  rcases hI with ⟨htarget, hvals⟩
  let n := I.values.length
  let fw := n
  let start := n + 1
  let sels := selectorWires n
  let acc := List.replicate I.width fw
  let core := compileSharedSubset start sels I.values acc fw fw I.target
  have hsv : sels.length = I.values.length := by simp [sels, n]
  have hacclen : acc.length = I.width := by simp [acc]
  have hvalsAcc : ∀ v ∈ I.values, v.length = acc.length := by
    intro v hv; rw [hacclen]; exact hvals v hv
  have hcoreLen := compileSharedSubset_length_bound (next := start) (falseWire := fw)
    (overflow := fw) (target := I.target) hsv hvalsAcc
  have hfullLen : (compileClosedSubset I).insts.length ≤
      1 + I.values.length * (20 * I.width + 1) + (2 * I.width + 3) := by
    change (TInstr.const fw false :: core.insts).length ≤ _
    simp only [List.length_cons]
    have ht : I.target.length = I.width := htarget
    have hcoreLen' : core.insts.length ≤
        I.values.length * (20 * I.width + 1) + (2 * I.width + 3) := by
      simpa [core, hacclen, ht, sels, n] using hcoreLen
    have hplus := Nat.add_le_add_left hcoreLen' 1
    simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hplus
  have hc := compileProgram_clause_bound (compileClosedSubset I).insts (compileClosedSubset I).output
  exact Nat.le_trans hc (Nat.add_le_add_right (Nat.mul_le_mul_left 3 hfullLen) 1)

/-- Literal-count companion to the closed clause bound. -/
theorem compileClosedSubset_cnf_literal_bound {I : SubsetSumFW} (hI : I.WellFormed) :
    cnfLiteralCount (compileProgram (compileClosedSubset I).insts (compileClosedSubset I).output) ≤
      7 * (1 + I.values.length * (20 * I.width + 1) + (2 * I.width + 3)) + 1 := by
  rcases hI with ⟨htarget, hvals⟩
  let n := I.values.length
  let fw := n
  let start := n + 1
  let sels := selectorWires n
  let acc := List.replicate I.width fw
  let core := compileSharedSubset start sels I.values acc fw fw I.target
  have hsv : sels.length = I.values.length := by simp [sels, n]
  have hacclen : acc.length = I.width := by simp [acc]
  have hvalsAcc : ∀ v ∈ I.values, v.length = acc.length := by
    intro v hv; rw [hacclen]; exact hvals v hv
  have hcoreLen := compileSharedSubset_length_bound (next := start) (falseWire := fw)
    (overflow := fw) (target := I.target) hsv hvalsAcc
  have hfullLen : (compileClosedSubset I).insts.length ≤
      1 + I.values.length * (20 * I.width + 1) + (2 * I.width + 3) := by
    change (TInstr.const fw false :: core.insts).length ≤ _
    simp only [List.length_cons]
    have ht : I.target.length = I.width := htarget
    have hcoreLen' : core.insts.length ≤
        I.values.length * (20 * I.width + 1) + (2 * I.width + 3) := by
      simpa [core, hacclen, ht, sels, n] using hcoreLen
    have hplus := Nat.add_le_add_left hcoreLen' 1
    simpa [Nat.add_comm, Nat.add_left_comm, Nat.add_assoc] using hplus
  have hc := compileProgram_literal_bound (compileClosedSubset I).insts (compileClosedSubset I).output
  exact Nat.le_trans hc (Nat.add_le_add_right (Nat.mul_le_mul_left 7 hfullLen) 1)

#print axioms WTC.compileClosedSubset_semantics
#print axioms WTC.naturalSubsetSum_exists_iff_target_sat
#print axioms WTC.compileClosedSubset_cnf_clause_bound
#print axioms WTC.compileClosedSubset_cnf_literal_bound

end WTC
