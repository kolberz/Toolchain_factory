import ExprCompiler

namespace WTC

def cnfLiteralCount : CNF → Nat
  | [] => 0
  | c :: cs => c.length + cnfLiteralCount cs

def BExpr.opCost : BExpr → Nat
  | .var _ => 0
  | .const _ => 1
  | .not e => e.opCost + 1
  | .and l r => l.opCost + r.opCost + 1
  | .or l r => l.opCost + r.opCost + 1

theorem compileExpr_length (e : BExpr) (next : Nat) :
    (compileExpr next e).insts.length = e.opCost := by
  induction e generalizing next with
  | var w => rfl
  | const v => rfl
  | not e ih => simp [compileExpr, BExpr.opCost, ih]
  | and l r ihl ihr =>
      simp [compileExpr, BExpr.opCost, ihl, ihr, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]
  | or l r ihl ihr =>
      simp [compileExpr, BExpr.opCost, ihl, ihr, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]

theorem compileInstr_clause_bound (i : TInstr) : (compileInstr i).length ≤ 3 := by
  cases i with
  | const d v => cases v <;> simp [compileInstr]
  | not d x => simp [compileInstr]
  | and d x y => simp [compileInstr]
  | or d x y => simp [compileInstr]

theorem compileInstr_literal_bound (i : TInstr) : cnfLiteralCount (compileInstr i) ≤ 7 := by
  cases i with
  | const d v => cases v <;> simp [compileInstr, cnfLiteralCount]
  | not d x => simp [compileInstr, cnfLiteralCount]
  | and d x y => simp [compileInstr, cnfLiteralCount]
  | or d x y => simp [compileInstr, cnfLiteralCount]

theorem cnfLiteralCount_append (x y : CNF) :
    cnfLiteralCount (x ++ y) = cnfLiteralCount x + cnfLiteralCount y := by
  induction x with
  | nil => simp [cnfLiteralCount]
  | cons c cs ih => simp [cnfLiteralCount, ih, Nat.add_assoc]

theorem flatMap_clause_bound (insts : List TInstr) :
    (insts.flatMap compileInstr).length ≤ 3 * insts.length := by
  induction insts with
  | nil => simp
  | cons i rest ih =>
      rw [List.flatMap_cons, List.length_append]
      have hi := compileInstr_clause_bound i
      simp only [List.length_cons]
      omega

theorem flatMap_literal_bound (insts : List TInstr) :
    cnfLiteralCount (insts.flatMap compileInstr) ≤ 7 * insts.length := by
  induction insts with
  | nil => simp [cnfLiteralCount]
  | cons i rest ih =>
      rw [List.flatMap_cons, cnfLiteralCount_append]
      have hi := compileInstr_literal_bound i
      simp only [List.length_cons]
      omega

theorem compileProgram_clause_bound (insts : List TInstr) (output : Nat) :
    (compileProgram insts output).length ≤ 3 * insts.length + 1 := by
  rw [compileProgram, List.length_append]
  have h := flatMap_clause_bound insts
  simp only [List.length_cons, List.length_nil]
  omega

theorem compileProgram_literal_bound (insts : List TInstr) (output : Nat) :
    cnfLiteralCount (compileProgram insts output) ≤ 7 * insts.length + 1 := by
  rw [compileProgram, cnfLiteralCount_append]
  have h := flatMap_literal_bound insts
  simp [cnfLiteralCount]
  omega

theorem expr_target_clause_bound (e : BExpr) (next : Nat) :
    let c := compileExpr next e
    (compileProgram c.insts c.output).length ≤ 3 * e.opCost + 1 := by
  let c := compileExpr next e
  have h : (compileProgram c.insts c.output).length ≤ 3 * c.insts.length + 1 :=
    compileProgram_clause_bound c.insts c.output
  have hlen : c.insts.length = e.opCost := by simpa [c] using compileExpr_length e next
  rw [hlen] at h
  exact h

theorem expr_target_literal_bound (e : BExpr) (next : Nat) :
    let c := compileExpr next e
    cnfLiteralCount (compileProgram c.insts c.output) ≤ 7 * e.opCost + 1 := by
  let c := compileExpr next e
  have h : cnfLiteralCount (compileProgram c.insts c.output) ≤ 7 * c.insts.length + 1 :=
    compileProgram_literal_bound c.insts c.output
  have hlen : c.insts.length = e.opCost := by simpa [c] using compileExpr_length e next
  rw [hlen] at h
  exact h

#print axioms WTC.compileProgram_clause_bound
#print axioms WTC.compileProgram_literal_bound
#print axioms WTC.expr_target_clause_bound
#print axioms WTC.expr_target_literal_bound

end WTC
